package gui;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JScrollBar;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.JSeparator;
import javax.swing.border.MatteBorder;

public class gui1 {

	private JFrame frame;
	private JTextField locationField;
	private JTextField dateField;
	private JTextField chantDesc;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gui1 window = new gui1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public gui1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 720, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel SearchPanel = new JPanel();
		SearchPanel.setBounds(0, 0, 720, 121);
		frame.getContentPane().add(SearchPanel);
		SearchPanel.setLayout(null);
		
		JPanel title = new JPanel();
		title.setBounds(0, 0, 721, 25);
		SearchPanel.add(title);
		
		JLabel lblNewLabel = new JLabel("Some title");
		title.add(lblNewLabel);
		
		JPanel location = new JPanel();
		location.setBounds(0, 24, 240, 50);
		SearchPanel.add(location);
		location.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Location");
		lblNewLabel_1.setBounds(20, 12, 61, 15);
		location.add(lblNewLabel_1);
		
		locationField = new JTextField();
		locationField.setBounds(100, 12, 114, 20);
		location.add(locationField);
		locationField.setColumns(10);
		
		JPanel date = new JPanel();
		date.setBounds(240, 24, 240, 50);
		SearchPanel.add(date);
		date.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Date");
		lblNewLabel_2.setBounds(20, 12, 34, 15);
		date.add(lblNewLabel_2);
		
		dateField = new JTextField();
		dateField.setBounds(100, 12, 114, 20);
		date.add(dateField);
		dateField.setColumns(10);
		
		JPanel event = new JPanel();
		event.setBounds(480, 24, 240, 50);
		SearchPanel.add(event);
		event.setLayout(null);
		
		
		String[] events = new String[] {"", "Christmas", "Easter", "Birth",
				"Lent", "Epiphany", "Ember Day", "Summer", "Winter",
				"Spring", "Autumn", "Memorial", "Valentine", "Advent",
				"Funeral"};
		
		JLabel lblNewLabel_3 = new JLabel("Event");
		lblNewLabel_3.setBounds(20, 12, 120, 15);
		event.add(lblNewLabel_3);
		
		JComboBox comboBox = new JComboBox(events);
		comboBox.setBounds(100, 12, 114, 20);
		event.add(comboBox);
		
		JPanel search = new JPanel();
		search.setBounds(240, 77, 240, 32);
		SearchPanel.add(search);
		
		JButton btnNewButton = new JButton("Search");
		search.add(btnNewButton);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(12, 119, 694, 2);
		SearchPanel.add(separator);
		
		JPanel ResultsPanel = new JPanel();
		ResultsPanel.setBounds(0, 120, 720, 320);
		frame.getContentPane().add(ResultsPanel);
		ResultsPanel.setLayout(null);
		
		JPanel chants = new JPanel();
		chants.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		chants.setBounds(12, 28, 100, 279);
		ResultsPanel.add(chants);
		chants.setLayout(null);
		
		JScrollBar chantList = new JScrollBar();
		chantList.setBounds(1, 1, 17, 278);
		chants.add(chantList);
		
		JPanel chantInfo = new JPanel();
		chantInfo.setBounds(114, 28, 594, 280);
		ResultsPanel.add(chantInfo);
		chantInfo.setLayout(null);
		
		chantDesc = new JTextField();
		chantDesc.setBounds(0, 0, 594, 280);
		chantInfo.add(chantDesc);
		chantDesc.setColumns(10);
		
		JLabel lblChant = new JLabel("Chant");
		lblChant.setBounds(34, 12, 70, 15);
		ResultsPanel.add(lblChant);
		
		JLabel lblNewLabel_4 = new JLabel("New label");
		lblNewLabel_4.setBounds(141, 12, 70, 15);
		ResultsPanel.add(lblNewLabel_4);
		
		JButton btnNewButton_1 = new JButton("Save Chant");
		btnNewButton_1.setBounds(589, 442, 117, 25);
		frame.getContentPane().add(btnNewButton_1);
	}
}
